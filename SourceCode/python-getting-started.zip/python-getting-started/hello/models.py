from django.db import models


# Create your models here.
class Greeting(models.Model):
    when = models.DateTimeField("date created", auto_now_add=True)
    fullname = models.CharField(max_length=200)
    industry = models.CharField(max_length=200)
    SKUNum = models.IntegerField(max_length=200)
    BarcodeNum = models.IntegerField(max_length=200)


class TrainingModel(models.Model):
    sales = models.DecimalField(max_length=200)
    label = models.DecimalField(max_length=200)
    cost = models.DecimalField(max_length=200)
    msrp = models.DecimalField(max_length=200)
    month = models.IntegerField(max_length=200)
    mon = models.IntegerField(max_length=200)
    tues = models.IntegerField(max_length=200)
    wed = models.IntegerField(max_length=200)
    thurs = models.IntegerField(max_length=200)
    fri = models.IntegerField(max_length=200)
    sat = models.IntegerField(max_length=200)
    sun = models.IntegerField(max_length=200)