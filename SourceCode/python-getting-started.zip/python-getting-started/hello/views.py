from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import messages
from .models import Greeting, TrainingModel
from .forms import GreetingForm
from django.http import HttpResponse, HttpResponseRedirect
import numpy as np
import pandas as pd
import sklearn
from sklearn import linear_model
from django.db import connection


# Create your views here.
def index(request):

    # ------------------ #
    #if __name__ == '__main__':
    # sales, label, cost, MSRP, month, mon, tues, wed, thurs, fri, sat, sun
    #data = pd.read_csv("DataSets\ForUse2.csv", sep=',')
    #data = TrainingModel.objects.all()
    query = str(TrainingModel.objects.all().query)
    data = pd.read_sql_query(query, connection)
    data = data[[
        'sales', 'label', 'cost', 'msrp', 'month', 'mon', 'tues', 'wed',
        'thurs', 'fri', 'sat', 'sun'
    ]]
    predict = 'label'

    #Training the model
    x = np.array(data.drop([predict], 1))
    y = np.array(data[[predict]])

    x_train, x_test, y_train, y_test = sklearn.model_selection.train_test_split(
        x, y, test_size=0.1)
    linear = linear_model.LinearRegression()

    #Training the model every time you refresh
    linear.fit(x_train, y_train)
    acc = linear.score(x_test, y_test)
    print(acc)
    percentage = (acc * 100)

    # Will get predictions from the parameters from DB.
    predictions = linear.predict(x_test)
    myResult = [len(predictions)]
    #myResult = [][len(predictions)]

    for x in range(len(predictions)):
        print((int)(predictions[x]), x_test[x], y_test[x])
        #myResult =

    #new table for holding real data

    # ------------------- #
    context = {"percentage": "percentage"}

    return render(request, "index.html", context)


def db(request):

    greeting = Greeting()
    greeting.save()

    greetings = Greeting.objects.all()
    print(greetings)
    return render(request, "db.html", {"greetings": greetings})


def create(request):
    form = GreetingForm()
    if request.method == 'POST':
        form = GreetingForm(request.POST)
        print(request.POST)
        if form.is_valid():
            form.save()
            #messages.info(request, 'Successfully verified!')

        else:
            form = GreetingForm()

    context = {'form': form}
    return render(request, "create.html", context)
